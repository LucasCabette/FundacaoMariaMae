// =========================
// LOGIN
// =========================
document.getElementById("loginForm")?.addEventListener("submit", function(event) {
    event.preventDefault();
    window.location.href = "menu.html";
});

// =========================
// NAVEGAÇÃO
// =========================
function consultarCadastros() {
    window.location.href = "pessoas.html";
}

function novoCadastro() {
    window.location.href = "novo-cadastro.html";
}

function voltarMenu() {
    window.location.href = "menu.html";
}

function escanearDocumento() {
    alert("Funcionalidade de escanear documento em desenvolvimento.");
}

function inserirManualmente() {
    alert("Tela de formulário manual em desenvolvimento.");
}

// =========================
// SAIR
// =========================
function sair() {
    window.location.href = "index.html";
}