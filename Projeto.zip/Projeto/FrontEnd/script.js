// URL da API REST no Spring Boot
const API_URL = "http://localhost:8080/api/assistidos";

// Dados fictícios locais para simulação caso o backend não esteja ativo
let assistidosFicticios = [
    { id: 1, codigoAssistido: "001", nome: "Ana Beatriz Silva", cpf: "123.456.789-01" },
    { id: 2, codigoAssistido: "002", nome: "Carlos Eduardo Lima", cpf: "987.654.321-00" },
    { id: 3, codigoAssistido: "003", nome: "Juliana Martins Alves", cpf: "111.222.333-44" },
    { id: 4, codigoAssistido: "004", nome: "Julio Souza Santos", cpf: "555.666.777-88" },
    { id: 5, codigoAssistido: "005", nome: "Fernanda Oliveira Costa", cpf: "999.888.777-66" },
    { id: 6, codigoAssistido: "006", nome: "Lucas Pereira Gomes", cpf: "222.333.444-55" }
];

// =========================
// NAVEGAÇÃO ENTRE TELAS
// =========================
document.getElementById("loginForm")?.addEventListener("submit", function(event) {
    event.preventDefault();
    window.location.href = "menu.html";
});

function consultarCadastros() { window.location.href = "pessoas.html"; }
function novoCadastro() { window.location.href = "novo-cadastro.html"; }
function voltarMenu() { window.location.href = "menu.html"; }
function escanearDocumento() { alert("Funcionalidade de escanear documento em desenvolvimento."); }
function inserirManualmente() { alert("Tela de formulário manual em desenvolvimento."); }
function sair() { window.location.href = "index.html"; }

// =========================
// BUSCA E RENDERIZAÇÃO
// =========================
async function carregarAssistidos(filtroNome = "", filtroCpf = "", filtroId = "") {
    try {
        let url = API_URL;
        if (filtroNome) url += `?nome=${encodeURIComponent(filtroNome)}`;
        
        const response = await fetch(url);
        if (!response.ok) throw new Error("Backend offline");

        const assistidos = await response.json();
        renderizarTabela(assistidos);

    } catch (error) {
        console.warn("Backend offline. Usando simulação local.");

        let resultado = assistidosFicticios.filter(item => {
            const bateuNome = !filtroNome || item.nome.toLowerCase().includes(filtroNome.toLowerCase().trim());
            const bateuCpf = !filtroCpf || item.cpf.replace(/\D/g, "").includes(filtroCpf.replace(/\D/g, "").trim());
            const bateuId = !filtroId || item.codigoAssistido.includes(filtroId.trim()) || item.id.toString() === filtroId.trim();
            
            return bateuNome && bateuCpf && bateuId;
        });

        renderizarTabela(resultado);
    }
}

function renderizarTabela(lista) {
    const tbody = document.querySelector(".tabela-dados tbody");
    if (!tbody) return;

    tbody.innerHTML = "";

    if (lista.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center" style="padding: 20px; color: var(--cor-texto-suave);">
                    Nenhum registro encontrado.
                </td>
            </tr>`;
        atualizarContador(0);
        return;
    }

    lista.forEach(item => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td><div class="avatar-circle">👤</div></td>
            <td>${item.nome}</td>
            <td>${item.cpf || 'Não informado'}</td>
            <td>${item.codigoAssistido || item.id}</td>
            <td class="text-center">
                <button class="btn-acao btn-editar" title="Editar" onclick="abrirModalEditar(${item.id})">✏️</button>
                <button class="btn-acao btn-excluir" title="Apagar" onclick="inativarAssistido(${item.id})">🗑️</button>
            </td>
        `;
        tbody.appendChild(tr);
    });

    atualizarContador(lista.length);
}

function atualizarContador(total) {
    const contador = document.querySelector(".paginacao-container span");
    if (contador) {
        contador.textContent = `Mostrando ${total} registro(s)`;
    }
}

function executarFiltroAtual() {
    const nome = document.getElementById("filtro-nome")?.value || "";
    const cpf = document.getElementById("filtro-cpf")?.value || "";
    const id = document.getElementById("filtro-id")?.value || "";
    carregarAssistidos(nome, cpf, id);
}

// =========================
// AÇÃO: APAGAR / INATIVAR
// =========================
async function inativarAssistido(id) {
    if (confirm("Deseja realmente apagar/inativar este registro?")) {
        try {
            const response = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
            if (!response.ok) throw new Error();
        } catch (error) {
            assistidosFicticios = assistidosFicticios.filter(a => a.id !== id);
        }
        
        alert("Registro removido com sucesso!");
        executarFiltroAtual();
    }
}

// =========================
// AÇÃO: EDITAR (MODAL)
// =========================
window.abrirModalEditar = function(id) {
    const modal = document.getElementById("modalEditar");
    if (!modal) {
        alert("Erro: O modal de edição não foi encontrado no HTML.");
        return;
    }

    const assistido = assistidosFicticios.find(a => a.id === id);

    if (assistido) {
        document.getElementById("edit-id").value = assistido.id;
        document.getElementById("edit-nome").value = assistido.nome;
        document.getElementById("edit-cpf").value = assistido.cpf || "";
        document.getElementById("edit-codigo").value = assistido.codigoAssistido || "";
    } else {
        document.getElementById("edit-id").value = id;
    }

    modal.style.display = "flex";
};

window.fecharModalEditar = function() {
    const modal = document.getElementById("modalEditar");
    if (modal) modal.style.display = "none";
};

// =========================
// INICIALIZAÇÃO E EVENTOS
// =========================
document.addEventListener("DOMContentLoaded", () => {
    const tabela = document.querySelector(".tabela-dados");

    if (tabela) {
        carregarAssistidos();

        const formFiltro = document.querySelector(".filtro-grid");
        formFiltro?.addEventListener("submit", (e) => {
            e.preventDefault();
            executarFiltroAtual();
        });
    }

    // Configuração do formulário de salvar alterações no Modal
    const formEditar = document.getElementById("formEditarAssistido");
    formEditar?.addEventListener("submit", async function(e) {
        e.preventDefault();

        const id = parseInt(document.getElementById("edit-id").value);
        const novoNome = document.getElementById("edit-nome").value;
        const novoCpf = document.getElementById("edit-cpf").value;
        const novoCodigo = document.getElementById("edit-codigo").value;

        try {
            const response = await fetch(`${API_URL}/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    nome: novoNome,
                    cpf: novoCpf,
                    codigoAssistido: novoCodigo,
                    dataNascimento: "1990-01-01"
                })
            });
            if (!response.ok) throw new Error();
        } catch (error) {
            // Atualiza localmente no modo offline
            const idx = assistidosFicticios.findIndex(a => a.id === id);
            if (idx !== -1) {
                assistidosFicticios[idx].nome = novoNome;
                assistidosFicticios[idx].cpf = novoCpf;
                assistidosFicticios[idx].codigoAssistido = novoCodigo;
            }
        }

        alert("Cadastro atualizado com sucesso!");
        window.fecharModalEditar();
        executarFiltroAtual();
    });
});