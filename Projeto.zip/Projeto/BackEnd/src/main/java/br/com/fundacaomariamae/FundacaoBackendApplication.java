package br.com.fundacaomariamae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundacaoBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(FundacaoBackendApplication.class, args);
    }
}
