package br.com.fundacaomariamae.assistido;

public enum StatusAssistido {
    ATIVO,
    INATIVO
}
