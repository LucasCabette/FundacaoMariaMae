package br.com.fundacaomariamae.assistido;

public enum Sexo {
    MASCULINO,
    FEMININO
}
