package br.com.fundacaomariamae.assistido;

import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AssistidoRepository extends JpaRepository<Assistido, Long> {
    Optional<Assistido> findByCodigoAssistido(String codigoAssistido);
    Optional<Assistido> findByCpf(String cpf);
    List<Assistido> findByNomeContainingIgnoreCase(String nome);
    boolean existsByNomeIgnoreCaseAndDataNascimento(String nome, LocalDate dataNascimento);
}
