# Backend inicial — Fundação Maria Mãe

Projeto inicial em Java 21 + Spring Boot + SQLite. Inclui CRUD básico de assistidos e verificação preliminar de duplicidade.

## Requisitos
- JDK 21
- Maven 3.9+ (ou Maven Wrapper adicionado pela IDE)
- IntelliJ IDEA, Eclipse ou VS Code com extensões Java

## Preparar o banco
1. Crie uma pasta `data` na raiz do projeto.
2. Copie para ela o arquivo `fundacao_maria_mae.sqlite` que foi gerado anteriormente.
3. Confira se o nome do arquivo é exatamente `fundacao_maria_mae.sqlite`.

A aplicação está configurada para usar o banco existente e **não** criar nem alterar tabelas automaticamente.

## Executar
Na raiz do projeto:
```bash
mvn spring-boot:run
```
A API ficará em `http://localhost:8080`.

## Endpoints iniciais
- `POST /api/assistidos` — cadastrar
- `GET /api/assistidos` — listar
- `GET /api/assistidos?nome=Maria` — pesquisar por nome
- `GET /api/assistidos/{id}` — buscar por ID
- `PUT /api/assistidos/{id}` — atualizar
- `DELETE /api/assistidos/{id}` — inativar (não apaga o registro)

## Exemplo de JSON para cadastro
```json
{
  "codigoAssistido": "2600000001",
  "nome": "Maria de Exemplo",
  "dataNascimento": "1990-04-18",
  "nomeMae": "Ana de Exemplo",
  "nomePai": null,
  "cpf": "12345678901",
  "rg": null,
  "cidadeNascimento": "Juiz de Fora",
  "sexo": "FEMININO"
}
```

Atenção: use apenas dados fictícios nos testes. O exemplo de CPF acima é ilustrativo e não deve ser usado como dado real.

## Observações importantes
- A verificação de nome + data de nascimento serve como alerta inicial; não substitui uma análise humana.
- O código do assistido é informado pelo cliente nesta primeira versão. A regra oficial para gerá-lo automaticamente precisa ser confirmada.
- O esquema SQLite foi criado para prototipação. Antes de usar dados reais, revisar segurança, LGPD, controle de acesso, backup e integração oficial com HikCentral e assinatura digital.
- O banco deve ter `PRAGMA foreign_keys = ON` em cada conexão SQLite que precisar validar chaves estrangeiras. A conexão Hibernate pode exigir configuração específica para garantir isso.
